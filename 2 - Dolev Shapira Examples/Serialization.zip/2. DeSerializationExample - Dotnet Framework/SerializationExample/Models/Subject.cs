﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializationExample.Models
{
    public enum Subject
    {
        History,
        Math,
        Physics,
        Chemistry,
        Biology
    }
}
