﻿using SerializationExample.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SerializationExample
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<StudentGrade>));

            FileStream stream = new FileStream("StudentGrades.xml", FileMode.Create);

            List<StudentGrade> studentGradeList = new List<StudentGrade>();

            studentGradeList.Add(new StudentGrade()
            {
                Grade = 77,
                StudentFirstName = "Dolev",
                StudentLastName = "Shapira",
                Subject = Subject.Biology
            });

            studentGradeList.Add(new StudentGrade()
            {
                Grade = 36,
                StudentFirstName = "Dor",
                StudentLastName = "Aviv",
                Subject = Subject.Chemistry
            });

            studentGradeList.Add(new StudentGrade()
            {
                Grade = 97,
                StudentFirstName = "Yaron",
                StudentLastName = "Sharon",
                Subject = Subject.History
            });

            studentGradeList.Add(new StudentGrade()
            {
                Grade = 85,
                StudentFirstName = "Noam",
                StudentLastName = "Gigi",
                Subject = Subject.Math
            });

            xmlSerializer.Serialize(stream, studentGradeList);
            stream.Close();


        }
    }
}
