﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PolyMorphismExample {
    internal class Program {
        static void Main(string[] args)
        {
            Parent a = new Son1();
            ((Son1)a).Son1Method();


            List<Parent> MyFamily = new List<Parent>();

            MyFamily.Add(new Parent());
            MyFamily.Add(new Son1());
            MyFamily.Add(new Son2());
            MyFamily.Add(new Parent());
            MyFamily.Add(new Son1());
            MyFamily.Add(new Son2());
            MyFamily.Add(new Parent());
            MyFamily.Add(new Son2());

            foreach(var item in MyFamily)
            {
                item.ParentMethod();

                if(item.GetType() == typeof(Son2))
                    ((Son2)item).Son2Method();

                if(item is Son2)
                    (item as Son2).Son2Method();
            }
            
            Assembly assembly = Assembly.Load("PolyMorphismExample");
            Type myType2 = assembly.GetTypes()[0];

            Type myType = a.GetType();
            MethodInfo[] methods =  myType.GetMethods();
            ConstructorInfo[] constructors = myType.GetConstructors();
            object aa = constructors[0].Invoke(new object[0]);

            foreach(MethodInfo method in methods)
            {
                if(method.Name.Contains("Dolev"))
                {
                    method.Invoke(a, new object[0]);
                }
            }

        }
    }
}
