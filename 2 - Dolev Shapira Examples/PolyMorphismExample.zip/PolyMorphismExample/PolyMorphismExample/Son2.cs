﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolyMorphismExample {
    internal class Son2 : Parent {
        public void Son2Method()
        {

        }
    }
}
