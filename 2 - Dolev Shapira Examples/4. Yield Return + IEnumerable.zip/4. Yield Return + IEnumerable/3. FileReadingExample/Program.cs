﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.FileReadingExample
{
    class Program
    {
        static IEnumerable<string> FileWhere(string path, Func<string, bool> condition)
        {
            IEnumerable<string> linesEnumerable = File.ReadLines(path);//Compare to - File.ReadAllLines()
            foreach (string fileLine in linesEnumerable)
            {
                if (condition(fileLine))
                    yield return fileLine;
            }
        }

        

        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = FileWhere("Migrations.txt", fileLine => fileLine.Contains('='));

            foreach (string name in myLinqResult)
            {
                Console.WriteLine("FileYieldMethod Result = " + name);
            }

            Console.ReadLine();
        }

        /*
        static IEnumerable<string> FileWhere2(string path, Func<string, bool> condition)
        {
            List<string> returnValue = new List<string>();

            IEnumerable<string> linesEnumerable = File.ReadLines(path);//Compare to - File.ReadAllLines()
            foreach(string fileLine in linesEnumerable)
            {
                if(condition(fileLine))
                    returnValue.Add(fileLine);
            }

            return returnValue;
        }*/
    }
}
