﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.ConditionAction
{
    class Program
    {
        static List<string> collection = new List<string> { "Michael", "Sharon", "Liran", "Dolev", "Dor", "Maria" };

        static IEnumerable<string> Where(Func<string, bool> condition)
        {
            foreach (string item in collection)
            {
                if (condition(item))
                    yield return item;
            }
        }

        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = Where((name) => name.StartsWith("D"));

            foreach (string name in myLinqResult)
            {
                Console.WriteLine(name);
            }
        }

        /*
        static bool MyCondition(string item)
        {
            return item.StartsWith("D");
        }*/
    }
}
