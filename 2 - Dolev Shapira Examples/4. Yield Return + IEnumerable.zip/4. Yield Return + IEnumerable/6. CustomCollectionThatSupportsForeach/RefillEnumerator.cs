﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.CustomCollectionThatSupportsForeach
{
    class RefillEnumerator : IEnumerator<string>
    {
        const int cacheSize = 5;

        ServerDB server = new ServerDB(cacheSize);

        private List<string> _clientCacheCollection = new List<string>(cacheSize);

        private int currentLocation = -1;
        

        public string Current => _clientCacheCollection[currentLocation % cacheSize];
        object IEnumerator.Current => _clientCacheCollection[currentLocation % cacheSize];

        public bool MoveNext()
        {
            currentLocation++;

            if (currentLocation % cacheSize == 0)
                _clientCacheCollection = server.DBMethod(currentLocation).ToList();

            return _clientCacheCollection.Count() > 0;
        }

        public void Dispose()
        {
        }

        public void Reset()
        {
            currentLocation = -1;
        }
    }
}
