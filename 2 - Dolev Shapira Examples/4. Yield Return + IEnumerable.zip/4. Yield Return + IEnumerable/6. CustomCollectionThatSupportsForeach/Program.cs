﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.CustomCollectionThatSupportsForeach
{
    class Program
    { 
        static void Main(string[] args)
        {
            ClientCacheCollection myCollection = new ClientCacheCollection();

            foreach (string name in myCollection)
            {
                Console.WriteLine(name);
            }
        }
    }
}
