﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.CustomCollectionThatSupportsForeach
{
    public class ServerDB
    {
        int _chuckSize;

        List<string> DB = new List<string> { "Michael", "Sharon", "Liran", "Dolev", "Dor", "Maria", "Noa" };

        public ServerDB(int chuckSize)
        {
            _chuckSize = chuckSize;
        }

        public IEnumerable<string> DBMethod(int startLocation)
        {
            if (startLocation >= DB.Count)
                return new string[0];

            string[] bufferToSend = new string[_chuckSize];

            for (int i = 0; i < _chuckSize && startLocation + i < DB.Count; i++)
            {
                bufferToSend[i] = DB[startLocation + i];
            }

            return bufferToSend;
        }
    }
}
