﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.FileReadingUsingEnumerator
{
    class Program
    {
        static IEnumerable<string> FileWhere(string path, Func<string, bool> condition, int maxItems)
        {
            int counter = 0;

            IEnumerable<string> linesEnumerable = File.ReadLines(path);//Compare to - File.ReadAllLines()
            IEnumerator<string> linesEnumerator = linesEnumerable.GetEnumerator();
            while (linesEnumerator.MoveNext() && counter < maxItems)
            {
                if (condition(linesEnumerator.Current))
                {
                    counter++;
                    yield return linesEnumerator.Current;
                }
            }
        }

        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = FileWhere("Migrations.txt", fileLine => fileLine.Contains('='), 5);

            foreach (string name in myLinqResult)
            {
                Console.WriteLine("FileYieldMethod Result = " + name);
            }

            Console.ReadLine();
        }
    }
}
