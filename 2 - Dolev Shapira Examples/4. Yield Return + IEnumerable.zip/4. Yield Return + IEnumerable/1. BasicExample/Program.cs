﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace _1.BasicExample
{
    class Program
    {
        static List<string> collection = new List<string> { "Michael", "Sharon", "Liran", "Dolev", "Dor", "Maria" };

        static IEnumerable<string> Where()
        {
            foreach (string item in collection)
            {
                yield return item;
            }
        }

        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = Where();

            foreach (string name in myLinqResult)
            {
                Console.WriteLine(name);
            }
        }
    }
}
