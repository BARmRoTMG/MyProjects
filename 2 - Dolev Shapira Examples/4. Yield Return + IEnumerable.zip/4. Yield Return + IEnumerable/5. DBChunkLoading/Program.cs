﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.DBChunkLoading
{
    class Program
    {
        const int chunkSize = 5;
        static List<string> DB = new List<string> { "Michael", "Sharon", "Liran", "Dolev", "Dor", "Maria", "Noa" };


        static IEnumerable<string> DBMethod(int startLocation)
        {
            Console.WriteLine("Connecting To Client");

            string[] bufferToSend = new string[chunkSize];

            for (int i = 0; i < chunkSize && startLocation + i < DB.Count; i++)
            {
                bufferToSend[i] = DB[startLocation + i];
            }

            return bufferToSend;
        }


        static IEnumerable<string> ClientLinqMethod()
        {
            IEnumerator<string> enumerator = null;
            IEnumerable<string> dbResult;
            int dbIndex = 0;
            bool continueLoop = true;
            do
            {
                if (dbIndex % chunkSize == 0)
                {
                    dbResult = DBMethod(dbIndex);
                    enumerator = dbResult.GetEnumerator();
                }

                continueLoop = enumerator.MoveNext();

                yield return enumerator.Current;
                dbIndex++;
            }
            while (continueLoop);
        }



        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = ClientLinqMethod();

            foreach (string name in myLinqResult)
            {
                Console.WriteLine(name);
            }
        }
    }
}
