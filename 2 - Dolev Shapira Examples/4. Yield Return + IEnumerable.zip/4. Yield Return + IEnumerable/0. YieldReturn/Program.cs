﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0.YieldReturn
{
    class Program
    {
        static List<string> collection = new List<string> { "Michael", "Sharon", "Liran", "Dolev", "Dor", "Maria" };



        static IEnumerable<string> BasicYieldMethod()
        {
            yield return "Michael";
            yield return "Sharon";
            yield return "Liran";
            yield return "Dolev";
            yield return "Dor";
            yield return "Maria";
        }

        static IEnumerable<string> ConsoleYieldMethod()
        {
            string result = string.Empty;
            while (result != "exit")
            {
                result = Console.ReadLine();
                yield return result;
            }
        }

        static void Main(string[] args)
        {
            IEnumerable<string> myLinqResult = BasicYieldMethod();

            foreach (string name in myLinqResult)
            {
                Console.WriteLine("BasicYieldMethod Result = " + name);
            }

            IEnumerable<string> myLinqResult2 = ConsoleYieldMethod();

            foreach (string name in myLinqResult2)
            {
                Console.WriteLine("ConsoleYieldMethod Result = " + name);
            }
        }
    }
}



