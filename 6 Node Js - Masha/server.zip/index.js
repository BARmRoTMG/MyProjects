const express = require('express');
const http = require('http');
const cors = require('cors');
const util =  require("util");
const fs =  require("fs");

const app = express();
app.use(cors());

const server = http.createServer(app);

const io = require('socket.io')(server, {
    cors: {
        origin: "http://localhost:3000"
    }
});

const dbFile = "./db/db.json";
const readFile = util.promisify(fs.readFile);
const writeFile = util.promisify(fs.writeFile);


io.on('connection', async (socket)=>{
    console.log("new connection established");

    let data = JSON.parse(await readFile(dbFile));

    socket.emit('getData', data)
    //socket.broadcast.emit('connection', data)

    socket.on('addItem', async (newItem)=>{
        let items = JSON.parse(await readFile(dbFile));
        items.push({title: newItem, id: Math.round(Math.random()*1000)});

        await writeFile(dbFile, JSON.stringify(items));

        socket.broadcast.emit('getData', items)
    })
    socket.on('disconnect', ()=>{
        console.log("client is disconnected");
    })
})


server.listen(8080, ()=>{
    console.log("listening on port 8080")
})