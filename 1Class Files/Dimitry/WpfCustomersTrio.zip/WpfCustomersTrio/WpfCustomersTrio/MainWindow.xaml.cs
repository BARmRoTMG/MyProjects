﻿using System.Linq;
using System.Windows;

namespace WpfCustomersTrio
{
    public partial class MainWindow : Window
    {
        int page = 0;
        int pageCount = 3;
        readonly DataService service = new DataService();

        public MainWindow()
        {
            InitializeComponent();
            SetCustomersToListView();
        }

        private void NextClick(object sender, RoutedEventArgs e)
        {
            page++;
            SetCustomersToListView();
        }

        private void BackClick(object sender, RoutedEventArgs e)
        {
            page--;
            SetCustomersToListView();
        }

        private void SetCustomersToListView()
        {
            lvCustomers.Items.Clear();
            var customers = service.Customers
                                    .Skip(page * pageCount)
                                    .Take(pageCount)
                                    .ToList();

            customers.ForEach(c => lvCustomers.Items.Add(c));

            tbAgeAvg.Text = customers.Average(c => c.Age).ToString();
        }
    }
}