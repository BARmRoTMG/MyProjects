﻿using System;
using System.IO;

namespace ConsoleWorksText
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var text = "";
            using (var file = new StreamReader("Stam.txt"))
                text = file.ReadToEnd();

            Console.WriteLine(text);
        }
    }
}
