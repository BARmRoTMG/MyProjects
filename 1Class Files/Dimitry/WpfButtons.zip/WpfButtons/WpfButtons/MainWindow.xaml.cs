﻿using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace WpfButtons
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var countButtons = 0;
            using (var sr = new StreamReader("buttons.config"))
                countButtons = int.Parse(sr.ReadLine());

            for (int i = 1; i <= countButtons; i++)
                spButtons.Children.Add(new Button { Content = i.ToString() });
        }
    }
}