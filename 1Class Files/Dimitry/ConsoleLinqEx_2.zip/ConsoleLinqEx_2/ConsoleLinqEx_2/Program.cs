﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleLinqEx_2
{
    struct Temp
    {
        public string Name;
        public int Count;
    }

    internal class Program
    {
        static readonly List<Customer> customers = new List<Customer>();

        static void Main(string[] args)
        {
            SetData();

            //ForEachExample();
            //OrderByExample();
            //GroupByExample();
            //SkipTakeExample();
            //FirstExamples();
            //JoinExamples();
        }

        private static void JoinExamples()
        {
            List<Customer> otherCustomers = new List<Customer>()
            {
                new Customer() { Name = "OK", Age = 54 },
                new Customer() { Name = "Stam" },
                new Customer() { Name = "First", Age = 3 },
                new Customer() { Name = "Good" },
                new Customer() { Name = "Best", Age = 12 },
                new Customer() { Name = "ERROR", Age = 39  },
            };

            //customers.Union(otherCustomers).ToList().ForEach(PrintCustomerDetails);

            //customers.Select(c => c.Name)
            //        .Union(otherCustomers.Select(c => c.Name))
            //        .ToList().ForEach(Console.WriteLine);

            //customers.Select(c => c.Name)
            //        .Except(otherCustomers.Select(c => c.Name))
            //        .ToList().ForEach(Console.WriteLine);


            //select c1.Id, c2.Name, c2.Age from Cust c1, OtherCust c2 where c1.Name = c2.Name
            //customers.Join(otherCustomers, c1 => c1.Name, c2 => c2.Name,
            //                                (c1, c2) => new { c1.Id, c2.Name, c2.Age })
            //    .ToList().ForEach(Console.WriteLine);

            List<string> names = new List<string> { "First", "Second", "Stam" };

            customers.Join(names, c1 => c1.Name, n1 => n1, (c1, n1) => c1.Name)
                         .ToList().ForEach(Console.WriteLine); ;
        }

        private static void FirstExamples()
        {
            //var c1 = customers.First();
            //var c1 = customers.Last();
            //var c1 = customers.First(c => c.Name.Contains("o"));
            var c1 = customers.FirstOrDefault(c => c.Name.Contains("ERROR"));
            //if (c1 != null)
            //    Console.WriteLine(c1.Name);
            //else
            //    Console.WriteLine("Anyone");
            //Console.WriteLine(c1 != null ? c1.Name : "Anyone");

            var c2 = customers.SingleOrDefault(c => c.Name == "First");
            Console.WriteLine(c2 != null ? c2.Name : "Anyone");
        }

        private static void SkipTakeExample()
        {
            int page = 3;
            int pageSize = 3;

            customers.Skip(page * pageSize)
                .Take(pageSize)
                .ToList()
                .ForEach(PrintCustomerDetails);
        }

        private static void GroupByExample()
        {
            //customers.Distinct().ToList().ForEach(PrintCustomerName);
            //customers.Select(c => c.Name)
            //            .Distinct()
            //            .ToList()
            //            .ForEach(Console.WriteLine);

            customers.GroupBy(c => c.Name)
                //.Select(c => new Temp { Name = c.Key, Count = c.Count() })
                .Select(c => new { Name = c.Key, Count = c.Count(), SumAge = c.Sum(a => a.Age) })
                .ToList()
                //.ForEach(t => Console.WriteLine($"{t.Name} - {t.Count}"));
                .ForEach(t => Console.WriteLine(t));
        }

        private static void OrderByExample()
        {
            //customers.Where(c => c.Age > 18).ToList().ForEach(PrintCustomerDetails);

            customers.Where(c => c.Age > 18)
                .OrderByDescending(c => c.Age)
                .ThenBy(c => c.Name)
                .ThenByDescending(c => c.Id)
                .ToList()
                .ForEach(PrintCustomerDetails);
        }

        private static void ForEachExample()
        {
            //customers.ForEach(c => Console.WriteLine(c.Name));
            //customers.ForEach(c => PrintCustomerName(c));
            //customers.ForEach(PrintCustomerName);

            customers.ForEach(c =>
            {
                Console.Write("Name: ");
                Console.WriteLine(c.Name);
            });

            //foreach (var c in customers)
            //{
            //    Console.WriteLine(c.Name);
            //}
        }

        private static void PrintCustomerName(Customer c)
        {
            Console.Write("Name: ");
            Console.WriteLine(c.Name);
        }

        private static void PrintCustomerDetails(Customer c)
        {
            Console.WriteLine($"{c.Id} - {c.Name} - {c.Age}");
        }

        private static void SetData()
        {
            customers.Add(new Customer { Id = 1, Name = "First", Age = 43 });
            customers.Add(new Customer { Id = 2, Name = "Second", Age = 16 });
            customers.Add(new Customer { Id = 3, Name = "Third", Age = 72 });
            customers.Add(new Customer { Id = 10, Name = "First", Age = 43 });
            customers.Add(new Customer { Id = 4, Name = "Fourth", Age = 25 });
            customers.Add(new Customer { Id = 5, Name = "Stam", Age = 43 });
            customers.Add(new Customer { Id = 6, Name = "OK", Age = 39 });
            customers.Add(new Customer { Id = 7, Name = "Good", Age = 43 });
            customers.Add(new Customer { Id = 8, Name = "Bad", Age = 25 });
            customers.Add(new Customer { Id = 11, Name = "First", Age = 43 });
            customers.Add(new Customer { Id = 12, Name = "Stam", Age = 71 });
        }
    }
}