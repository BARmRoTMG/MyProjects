﻿namespace Logic
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public void UpdateId(int id) => Id = id;
    }
}