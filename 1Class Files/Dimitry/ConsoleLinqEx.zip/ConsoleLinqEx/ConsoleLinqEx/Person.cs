﻿namespace ConsoleLinqEx
{
    //class Person
    //{
    //    public string Name { get; set; }
    //}

    class Child //: Person
    {
        public string Name { get; set; }
        public string Address { get; set; }
        //public string School { get; set; }
    }

    class Adult : Child
    {
        public double Salary { get; set; }
    }
}