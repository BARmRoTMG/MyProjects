﻿namespace ConsoleLinqEx
{
    class Square : Rectangle
    {
        private int width;
        //private int height;

        public override int Width
        {
            get => width; set
            {
                width = value;
                //height = width;
            }
        }
        //public override int Height
        //{
        //    get => height; set
        //    {
        //        height = value;
        //        width = height;
        //    }
        //}
    }

    class Rectangle
    {
        public virtual int Width { get; set; }
        public virtual int Height { get; set; }

        public int Area() => Width * Height;
    }
}
