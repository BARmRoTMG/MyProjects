﻿using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace ConsoleLinqEx
{
    class Stam
    {
        public int NonStat { get; set; }
        public static int MyStat { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            var s1 = new Stam { NonStat = 1, /*MyStat = 2*/ };
            var s2 = new Stam { NonStat = 2, /*MyStat = 2*/ };
            var s3 = new Stam { NonStat = 3, /*MyStat = 2*/ };

            Stam.MyStat = 5;
            Stam.MyStat = 6;

            //Shapes();

            var customer = new Customer();
            customer.UpdateId(9);
            customer.UpdateName("New");

            var c1 = customer.UpdateCustomer()
                                .UpdateCustomer()
                                .UpdateCustomer()
                                .UpdateCustomer();

            CustomerExtentions.UpdateCustomer(customer);
            customer.UpdateCustomer();

            Console.WriteLine(c1.Id);


            int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            var res = numbers.Where(n => n > 2 & n != 5)
                                .Where(n => n < 9)
                                .Where(n => n % 2 == 0);

            //Aggregations(numbers);
            //WhereEx(numbers);
        }

        private static void Shapes()
        {
            List<Rectangle> rectangles = new List<Rectangle>();
            rectangles.Add(new Rectangle { Height = 10, Width = 20 });
            rectangles.Add(new Square { Height = 10, Width = 20 });

            foreach (var shape in rectangles)
            {
                Console.WriteLine($"{shape.GetType().Name} = {shape.Area()}");
            }

            List<SquareOK> squares = new List<SquareOK>();
            squares.Add(new RectangleOK { Height = 10, Width = 20 });
            //squares.Add(new SquareOK { Height = 10, Width = 20 });
        }

        private static void Aggregations(int[] numbers)
        {
            Console.WriteLine(numbers.Count());
            Console.WriteLine(numbers.Min());
            Console.WriteLine(numbers.Max());
            Console.WriteLine(numbers.Average());
            Console.WriteLine(numbers.Sum());

            Console.WriteLine(numbers.Count(n => n % 2 == 0));
            Console.WriteLine(numbers.Where(n => n % 2 == 0).Average());
        }

        private static void WhereEx(int[] numbers)
        {
            var res1 = numbers.Where(n => n > 2);
            var res2 = res1.Where(n => n < 9);
            var res3 = res2.Where(n => n != 5);
            var res4 = res3.Where(n => n % 2 == 0);

            foreach (var item in res4)
            {
                Console.WriteLine(item);
            }

            //WhereExample(numbers);
        }

        private static void WhereExample(int[] numbers)
        {
            //foreach (var n in numbers)
            //{
            //    if (n % 2 == 0)
            //        Console.WriteLine(n);
            //}

            //var oldStyle = from n in numbers
            //             where n % 2 == 0
            //             select n;

            var newStyle = numbers.Where(n => n % 2 == 0); //select * from numbers where n % 2 == 0

            if (newStyle.Count() > 10)
                foreach (var item in newStyle)
                    Console.WriteLine(item);

            var newStyle2 = newStyle.Where(n => n % 3 == 0); //select * from numbers where n % 2 == 0 and n % 3 == 0 
            foreach (var item in newStyle2)                  //EXECUTE
                Console.WriteLine(item);
        }
    }
}
