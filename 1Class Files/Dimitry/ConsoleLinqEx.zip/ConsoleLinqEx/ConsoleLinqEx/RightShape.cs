﻿namespace ConsoleLinqEx
{
    class SquareOK
    {
        public virtual int Width { get; set; }
        public virtual int Area() => Width * Width;
    }

    class RectangleOK : SquareOK
    {
        public override int Width { get; set; }
        public int Height { get; set; }

        public override int Area() => Width * Height;
    }


    class A
    {
        public int Id { get; set; }
    }

    class B : A
    {
        public int Type { get; set; }
    }

    class C : B
    {
        public double Stam { get; set; }
    }



    abstract class Animal
    {
        public virtual void Run() { }
    }

    class Bird : Animal
    {
        public void Fly() { }
    }
}
