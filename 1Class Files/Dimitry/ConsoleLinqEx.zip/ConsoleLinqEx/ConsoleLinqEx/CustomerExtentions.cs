﻿using Logic;

namespace ConsoleLinqEx
{
    class Example
    {
        public Example()
        {
            var customer = new Customer();
            CustomerNotExtentions.UpdateCustomer2(customer);
            CustomerExtentions.UpdateCustomer(customer);
            customer.UpdateCustomer();

            int i = 10;
            i.IncreaseNumber()
                .IncreaseNumber()
                .IncreaseNumber()
                .IncreaseNumber()
                .IncreaseNumber()
                .IncreaseNumber();
        }
    }

    class CustomerNotExtentions
    {
        public static Customer UpdateCustomer2(Customer customer)
        {
            customer.Id++;
            return customer;
        }
    }

    static class CustomerExtentions
    {
        public static void UpdateName(this Customer customer, string name) => customer.Name = name;

        public static Customer UpdateCustomer(this Customer customer)
        {
            customer.Id++;
            return customer;
        }

        public static int IncreaseNumber(this int num) => ++num;
    }
}
