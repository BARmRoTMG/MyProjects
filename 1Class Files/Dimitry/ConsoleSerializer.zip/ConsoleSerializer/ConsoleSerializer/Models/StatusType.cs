﻿namespace ConsoleSerializer.Models
{
    public enum StatusType
    {
        Platinum,
        Gold,
        Silver
    }
}