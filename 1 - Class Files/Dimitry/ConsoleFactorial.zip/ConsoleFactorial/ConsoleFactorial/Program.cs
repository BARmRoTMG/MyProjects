﻿using System;

namespace ConsoleFactorial
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //5! = 5 * 4 * 3 * 2 * 1 = 120
            if (args == null || args.Length < 1)
                throw new ArgumentException(nameof(args));

            if (!int.TryParse(args[0], out int number))
                throw new ArgumentException("This isn't number");
            if (number < 1)
                throw new ArgumentException("The number must be more then 1");

            int result = 1;
            for (int i = 1; i <= number; i++)
                result *= i;

            Console.WriteLine($"Factorial of number {number} is {result}");
        }
    }
}