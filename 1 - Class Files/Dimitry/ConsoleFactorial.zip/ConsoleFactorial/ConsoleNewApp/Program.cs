﻿using System;

namespace ConsoleNewApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //for (int i = 2; i < 10; i++)
            //    Process.Start("ConsoleFactorial.exe", i.ToString());

            AppDomain domain = AppDomain.CreateDomain("Factorial Domain");
            domain.DomainUnload += Domain_DomainUnload;

            for (int i = 2; i < 10; i++)
                domain.ExecuteAssembly("ConsoleFactorial.exe", new string[] { i.ToString() });

            AppDomain.Unload(domain);
        }

        private static void Domain_DomainUnload(object sender, EventArgs e)
        {
            Console.WriteLine("Domain Unloaded");
        }
    }
}