﻿namespace ConsoleCustomers
{
    internal class Product
    {
        public string Title { get; set; }
    }
}