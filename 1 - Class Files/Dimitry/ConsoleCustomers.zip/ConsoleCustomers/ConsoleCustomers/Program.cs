﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleCustomers
{
    internal class Program
    {
        static List<Customer> customers = new List<Customer>();

        static void Main(string[] args)
        {
            SubStrings();

            WorksOnFile();
            WorksOnMemory();
        }

        private static void SubStrings()
        {
            var s = "free text stam OK";
            Console.WriteLine(s.IndexOf("e"));
            Console.WriteLine(s.Substring(0, s.Length));
            Console.WriteLine(s.Substring(3, 4));

            var res = s.Split(' ');
            Console.WriteLine(res.Count());
        }

        private static void WorksOnMemory()
        {
            foreach (var customer in customers)
            {
                Console.WriteLine($"{customer.Id} - {customer.Name}");
                foreach (var product in customer.Products)
                    Console.WriteLine($"---{product.Title}");
            }
        }

        private static void WorksOnFile()
        {
            using (var reader = new StreamReader("customers.txt"))
            {
                //0 : Ofik - 10
                //1 : Tomer - 13
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var customer = new Customer
                    {
                        Id = int.Parse(line.Split('-')[1].Trim()),
                        Name = line.Split('-')[0].Split(':')[1].Trim(),
                        //Name = line.Substring(line.IndexOf(":") + 1, line.IndexOf("-") - line.IndexOf(":") - 2),
                        Products = new List<Product>()
                    };
                    customers.Add(customer);
                }
            }
        }
    }
}