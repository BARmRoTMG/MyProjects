﻿using System;
using System.Threading;

namespace Logic
{
    public class Movement
    {
        public event Action<string> PrintEvent;  //List<0x111>
        public Action<string> PrintAction { get; set; } //0x111
        public Func<int, bool> ExitFunc { get; set; }   //0x222

        public void Move(int distance)
        {
            for (int i = 0; i < distance; i++)
            {
                //PrintAction?.Invoke($"Walking {i} meters...");  //call 0x111
                PrintEvent?.Invoke($"Walking {i} meters...");  //call foreach List<0x111>
                
                if (ExitFunc?.Invoke(i) == true)    //call 0x222
                    return;

                Thread.Sleep(1000);
            }
        }
    }
}