﻿using Logic;
using System;

namespace ConsoleWalking
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var movement = new Movement();
            //movement.PrintAction += Print;   //PrintAction = 0x111
            //movement.PrintAction -= Print;   //PrintAction = 0x111
            //movement.PrintAction += Print;   //PrintAction = 0x111
            //movement.PrintAction = Print;    //PrintAction = 0x111
            //movement.PrintAction += Print;   //PrintAction = 0x111

            movement.PrintEvent += Print;   //PrintAction.Add(0x111)
            movement.PrintEvent += Print;   //PrintAction.Add(0x111)
            movement.PrintEvent += Print;   //PrintAction.Add(0x111)
            movement.PrintEvent -= Print;   //PrintAction.Remove(0x111)
            movement.PrintEvent -= Print;   //PrintAction.Remove(0x111)

            movement.ExitFunc = ConsoleExit;   //ExitFunc = 0x222

            movement.Move(20);
        }

        //0x111
        static void Print(string msg) => Console.WriteLine(msg);

        //0x222
        private static bool ConsoleExit(int i) => i > 8;

    }
}