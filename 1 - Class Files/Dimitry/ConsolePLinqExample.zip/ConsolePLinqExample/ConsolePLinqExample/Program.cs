﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace ConsolePLinqExample
{
    /// <summary>
    /// PLinq = Parallel Linq
    /// </summary>
    internal class Program
    {
        static int counter;
        static string freeText = "Text messaging, or texting, is the act of composing and sending electronic messages, typically consisting of alphabetic and numeric characters";

        /// <summary>
        /// This main for start
        /// </summary>
        /// <param name="args">args from CMD</param>
        static void Main(string[] args)
        {
            if (args[0] == "exit") return;

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            //freeText.ToList().ForEach(CheckLetter);
            freeText.AsParallel().ForAll(CheckLetter);

            Console.WriteLine($"char 'e' = {counter} times");
            Console.WriteLine($"msec = {stopwatch.ElapsedMilliseconds}");
        }

        /// <summary>
        /// Validation
        /// </summary>
        /// <param name="c">char</param>
        private static void CheckLetter(char c)
        {
            Thread.Sleep(100);
            if (c == 'e')
                counter++;
            //Console.WriteLine(c);
        }
    }
}