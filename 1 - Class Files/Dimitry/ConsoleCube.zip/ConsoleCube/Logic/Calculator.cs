﻿using System;

namespace Logic
{
    public class Calculator
    {
        public Action ErrorAct { get; set; }    // = 0x555

        public void GetCubeOfNumber(string num)
        {
            if (int.TryParse(num, out int res))
            {
                //PrintResult()
            }
            else
            {
                ErrorAct?.Invoke(); //call 0x555
            }
        }
    }
}