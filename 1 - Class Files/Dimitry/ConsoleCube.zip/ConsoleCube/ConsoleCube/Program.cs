﻿using Logic;
using System;

namespace ConsoleCube
{
    internal class Program
    {
        static string number;
        static readonly Calculator calc = new Calculator();

        static void Main(string[] args)
        {
            calc.ErrorAct = Error; //ErrorAct = 0x555
            PrintCubeOfNumber();
        }

        //0x333
        private static void PrintCubeOfNumber()
        {
            Console.WriteLine("Insert number:");
            number = Console.ReadLine();
            calc.GetCubeOfNumber(number);
        }

        //0x444
        private static void PrintResult(string result) => 
            Console.WriteLine($"Cube of number {number} = {result}");

        //0x555
        private static void Error()
        {
            Console.WriteLine("Incorrect input!");
            PrintCubeOfNumber();    //call 0x333
        }
    }
}