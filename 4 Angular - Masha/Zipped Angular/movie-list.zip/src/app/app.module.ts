import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MovieListComponent } from './components/movie-list/movie-list.component';
import { MovieEditorComponent } from './components/movie-editor/movie-editor.component';
import { MovieComponent } from './components/movie/movie.component';
import { FormsModule } from '@angular/forms';
import { AboutComponent } from './components/about/about.component';
import { HomeComponent } from './components/home/home.component';
import { routing } from './routing';
import { AboutAppComponent } from './components/about/about-app/avout-app.component';
import { AboutTeamComponent } from './components/about/about-team/about-team.component';
import { HelpComponent } from './components/about/help/help.component';
import { MovieDetailsComponent } from './components/movie-details/movie-details.component';

@NgModule({
  declarations: [
    AppComponent,
    MovieListComponent,
    MovieEditorComponent,
    MovieComponent,
    AboutComponent,
    HomeComponent,
    AboutAppComponent,
    AboutTeamComponent,
    HelpComponent,
    MovieDetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
