import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable } from 'rxjs';
import Movie from '../model/movie.model';


@Injectable({
  providedIn: 'root'
})
export class MovieService {

  private url = "http://localhost:4100/movies/";

  constructor(private httpClient: HttpClient) { }

  get() {
    return this.httpClient.get(this.url)
      .pipe(catchError((error: any) => {
        // this.errorMessage = error.message;
        console.error('There was an error!', error);

        // after handling error, return a new observable 
        // that doesn't emit any values and completes
        throw new Error(error.message)
      }))
  }

  getById(id: number){
    return this.httpClient.get(this.url+id)
    .pipe(catchError((error: any) => {
      // this.errorMessage = error.message;
      console.error('There was an error!', error);

      // after handling error, return a new observable 
      // that doesn't emit any values and completes
      throw new Error(error.message)
    }))
  }

  post(movie: Movie) {
    return this.httpClient.post(this.url, movie)
      .pipe(catchError((error: any) => {
        console.error('There was an error!', error);
        throw new Error(error.message)
      }))
  }

  put(movie?: Movie) {
    return this.httpClient.put(this.url + movie?.id, movie)
      .pipe(catchError((error: any) => {
        console.error('There was an error!', error);
        throw new Error(error.message)
      }))
  }

  delete(id: number) {
    return this.httpClient.delete(this.url + id)
      .pipe(catchError((error: any) => {
        console.error('There was an error!', error);
        throw new Error(error.message)
      }));
  }

}
