// class Movie {
//    id: number = 0;
//    name: string = "";
//    description: string = "";
//    year: number = 0;
//    wasWatched: boolean =false;
//    image: string = "";
// }

interface Movie {
    id: number;
    name: string;
    description: string;
    year: number;
    wasWatched: boolean;
    image: string; 
}

export default Movie