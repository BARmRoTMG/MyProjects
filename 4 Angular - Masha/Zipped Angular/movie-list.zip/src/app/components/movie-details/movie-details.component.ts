import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import Movie from 'src/app/model/movie.model';
import { MovieService } from 'src/app/servies/movie.service';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent {
  movie?: Movie;
  id: number=0;

  constructor(private route: ActivatedRoute, private movieService: MovieService){
      this.route.params.subscribe((params)=>{

          this.id = Number(params["id"]);

          this.movieService.getById(this.id).subscribe(data=>{
            this.movie = data as Movie;
          })

      })
  }
}
