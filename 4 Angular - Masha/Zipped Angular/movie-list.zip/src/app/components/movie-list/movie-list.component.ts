import { Component, OnInit } from '@angular/core';
import Movie from 'src/app/model/movie.model';
import { MovieService } from 'src/app/servies/movie.service';

@Component({
  selector: 'movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent {
  
  movieList: Movie[]= []

  constructor(private movieService: MovieService){
    this.movieService.get().subscribe((data)=>{
        this.movieList = data as Movie[];
    })
  }

  onDelete(id: number){
      this.movieService.delete(id).subscribe((data)=>{
        this.movieList = this.movieList.filter(item => item.id != id);
      })
  }
  onDuplicate(movie: Movie){
    let newMovie = {...movie, id: 0};
    this.movieService.post(newMovie).subscribe(data=>{
      this.movieList.push(data as Movie)
    })
  }

 }
