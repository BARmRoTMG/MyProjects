import { Component, Input } from '@angular/core';
import Movie from 'src/app/model/movie.model';

@Component({
  selector: 'movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent {
  @Input() data?: Movie;
  
}
