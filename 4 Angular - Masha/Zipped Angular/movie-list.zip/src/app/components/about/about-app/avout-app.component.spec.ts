import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvoutAppComponent } from './avout-app.component';

describe('AvoutAppComponent', () => {
  let component: AvoutAppComponent;
  let fixture: ComponentFixture<AvoutAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AvoutAppComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AvoutAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
