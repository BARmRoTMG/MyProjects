import { Component } from '@angular/core';

@Component({
  selector: 'app-about-app',
  templateUrl: './avout-app.component.html',
  styleUrls: ['./avout-app.component.css']
})
export class AboutAppComponent {

}
