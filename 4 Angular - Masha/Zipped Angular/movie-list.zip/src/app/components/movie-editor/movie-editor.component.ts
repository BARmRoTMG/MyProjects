import { outputAst } from '@angular/compiler';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import Movie from 'src/app/model/movie.model';
import { MovieService } from 'src/app/servies/movie.service';

@Component({
  selector: 'movie-editor',
  templateUrl: './movie-editor.component.html',
  styleUrls: ['./movie-editor.component.css']
})
export class MovieEditorComponent {
    @Input() movie?: Movie;
    @Output() onDelete: EventEmitter<any> = new EventEmitter<any>();
    @Output() onDuplicate: EventEmitter<any> = new EventEmitter<any>();
 
    showEditor: boolean = false;

    constructor(private movieService: MovieService){}

    updateDatabase(){
      this.movieService.put(this.movie).subscribe(data=>{
        // display message?
      })
    }

    deleteMovie(){
        this.onDelete.emit(this.movie?.id);
    }
    duplicateMovie(){
      this.onDuplicate.emit(this.movie);
    }
}
