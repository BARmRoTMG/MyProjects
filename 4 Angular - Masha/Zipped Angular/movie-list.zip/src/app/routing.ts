import {Routes, RouterModule} from '@angular/router';
import { AboutAppComponent } from './components/about/about-app/avout-app.component';
import { AboutTeamComponent } from './components/about/about-team/about-team.component';
import { AboutComponent } from './components/about/about.component';
import { HelpComponent } from './components/about/help/help.component';
import { HomeComponent } from './components/home/home.component';
import { MovieDetailsComponent } from './components/movie-details/movie-details.component';
import { MovieListComponent } from './components/movie-list/movie-list.component';


const appRoutes: Routes = [
    {path: 'list', component: MovieListComponent},
    {path: 'movie/:id', component: MovieDetailsComponent},

    {path: 'about', component: AboutComponent, children: [
        {path: 'app', component: AboutAppComponent },
        {path: 'team', component: AboutTeamComponent },
        {path: 'help', component: HelpComponent },
        {path: '', redirectTo: 'app', pathMatch: 'full'},
    ]},
    {path: '', component: HomeComponent}
]

export const routing = RouterModule.forRoot(appRoutes);

