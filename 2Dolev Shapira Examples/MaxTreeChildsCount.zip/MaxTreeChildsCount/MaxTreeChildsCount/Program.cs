﻿using System;

namespace MaxTreeChildsCount {
    internal class Program {
        static int[] MyTree = new int[27] { -1, -1, 1, 0, 1, 3, 3, 2, 5, 4, 5, 11, 7, 9, 12, 4, 1, 6, 10, 13, 8, 2, 15, 5, 14, 6, 11 };

        static int countChilds = 0;

        static int CountChild(int[] MyTree, int parent, int currentLevel)
        {
            int countChilds = 0;

            for(int i = parent; i < MyTree.Length; i++)
            {
                if(MyTree[i] == parent)
                {
                    countChilds++;
                    if(currentLevel < 1)
                        countChilds += CountChild(MyTree, i, currentLevel + 1);
                }
            }
            return countChilds;
        }

        static int GetMaxChildCountsForTree(int[] MyTree)
        {
            countChilds = 0;
            int maxChildCount = 0;

            for(int i = 0; i < MyTree.Length; i++)
            {
                int tmp = 0;
                tmp = CountChild(MyTree, i, 0);
                if(maxChildCount < tmp)
                    maxChildCount = tmp;
            }

            return maxChildCount;
        }








        static void Main(string[] args)
        {
            int max = GetMaxChildCountsForTree(MyTree);
        }
    }
}
