﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsExample {
    internal class GenericMethod {

        public void A<GenericType>(GenericType param)
        {

        }

        public void B<GenericType>(GenericType param)
        {

        }

        public void C<GenericType>(GenericType param)
        {

        }
    }
}
