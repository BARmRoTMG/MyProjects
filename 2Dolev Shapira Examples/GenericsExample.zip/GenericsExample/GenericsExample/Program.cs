﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsExample {
    internal class Program {
        static void Main(string[] args)
        {
            GenericsClass<MyClass> genericClass = new GenericsClass<MyClass>(new MyClass());
            MyClass myVar1 = genericClass.myVar;
            MyClass myVar2 = genericClass.myVar;




            GenericMethod genericMethod = new GenericMethod();
            genericMethod.A<int>(55);
            genericMethod.B<string>("dfgdg");
            genericMethod.C<double>(55);
            genericMethod.A<int>(55);
            genericMethod.A<string>("dfgdfgdfgdf");


        }
    }
}
