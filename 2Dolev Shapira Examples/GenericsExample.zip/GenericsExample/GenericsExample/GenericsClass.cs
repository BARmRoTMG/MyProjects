﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsExample {
    internal class GenericsClass<GenericType22> where GenericType22 : MyIntefrace, new() {

        public GenericType22 myVar;

        public GenericsClass(GenericType22 myVar)
        {
            myVar = new GenericType22();
            this.myVar = myVar;
        }


        public void MyMethod(GenericType22 param)
        {

        }


    }
}
