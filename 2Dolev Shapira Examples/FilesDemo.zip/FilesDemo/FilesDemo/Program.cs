﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesDemo {
    class Program {
        static void Main(string[] args)
        {
            /*
            Directory.CreateDirectory("MyDir");

            byte[] byteArray = new byte[] { 66, 22, 28, 15, 86 };

            File.WriteAllText("dolev.txt","gfxgfcvncnfgn");
            File.WriteAllBytes("dolev2.txt", byteArray);

            FileStream file = File.Open("dolev3.txt", FileMode.OpenOrCreate);
            file.Write(byteArray,0,byteArray.Length);
            file.Seek(file.Length, SeekOrigin.Begin);
            file.Write(byteArray, 0, byteArray.Length);
            file.Close();

            FileStream file2 = File.Open("dolev3.txt", FileMode.OpenOrCreate);
            file2.Read(byteArray, 0, byteArray.Length);
            file2.Read(byteArray, 0, byteArray.Length);
            file2.Read(byteArray, 0, byteArray.Length);
            file2.Read(byteArray, 0, byteArray.Length);
            file2.Close();

            using(MemoryStream m = new MemoryStream())
            {

            }

            if(File.Exists("dolev.txt") || Directory.Exists("MyDir"))
            {

            }*/

            File.WriteAllText($@"MyDir\File1.txt","test1");
            File.WriteAllText($"MyDir\\File2.txt","test2");
            File.WriteAllText($"MyDir\\File3", "test3");

            string[] allFiles = Directory.GetFiles("MyDir", "*.txt", SearchOption.AllDirectories);
            
            
            //Bitmap bitmap = new Bitmap("MyFile.bmp");
            //bitmap.

        }
    }
}
